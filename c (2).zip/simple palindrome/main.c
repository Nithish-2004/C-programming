#include <stdio.h>
int main()
{  
    char str[50]; 
    int sum=0;
    scanf("%[\n]s",str);
    int length=0;  
    for(int i=0;str[i]!='\0';i++) 
    length++;
    for(int i=0,j=length-1;i<j;i++,j--)  
    {  
        if(str[i]!=str[j])  
        {  
            printf("Not palindrome");  
        }  
    }  
    printf("Palindrome"); 
    
}
#include <stdio.h>

int main()
{
    char str1[20];
    fgets(str1,11,stdin);
    printf("%s",str1);
  
    
    return 0;
}
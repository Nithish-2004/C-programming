#include <stdio.h>  
#include <ctype.h>  

int sumOfDigits(const char *str) {  
    int sum = 0;  
    while (*str) {  
        if (isdigit(*str)) {  
            sum += *str - '0';  
        }  
        str++;  
    }  
    return sum;  
}  

int main() {  
    const char* input = "a1b2c3d4"; 
    int result = sumOfDigits(input);  
    printf("Sum of digits: %d\n", result);  
    return 0;  
}
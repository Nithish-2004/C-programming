#include <stdio.h>  
struct d  
{  
    int a;  
    int b;  
};  

int main()  
{  
    struct d e;  
    e.a=5;  
    e.b=7;  
    struct d * ptr=&e;  
    printf("%d",ptr->a);  
    printf("%d",ptr->b);  
    return 0;  
}
#include <stdio.h>
float BankBalnce(){
float income=26000;  
float emi=25000;  
float loan=1000;  
return income-emi-loan;  
}
int main()  
{  
    printf("%f",BankBalnce());  
    return 0;  
}

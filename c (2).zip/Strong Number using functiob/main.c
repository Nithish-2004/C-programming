#include <stdio.h>
int fact(int n)
{
    int p=1;
    while(n!=0)
    {
        
        p=p*n--;
    }
    return p;
    
}
void  Strong_Number(int num)
{   int sum=0;
    int temp=num;
    while(num!=0)
    {   
        int l=num%10;
        sum=sum+fact(l);
        num=num/10;
    }
    if(sum==temp)
    {
        printf("Strong Number");
    }
  
    
    
} 
int main()
{
  Strong_Number(145);

    return 0;
}

    

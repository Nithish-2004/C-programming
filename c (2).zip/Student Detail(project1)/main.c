#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_STUDENTS 100

typedef struct {
    char name[50];
    int rollno;
    char phoneno[15];
    int num_subjects;
    float fees;
} Student;

Student students[MAX_STUDENTS];
int student_count = 0;

void addStudent() {
    if (student_count >= MAX_STUDENTS) {
        printf("Database is full!\n");
        return;
    }
    
    Student new_student;
    printf("Enter student name: ");
    scanf("%s", new_student.name);
    printf("Enter roll number: ");
    scanf("%d", &new_student.rollno);
    printf("Enter phone number: ");
    scanf("%s", new_student.phoneno);
    printf("Enter number of subjects: ");
    scanf("%d", &new_student.num_subjects);
    printf("Enter fees: ");
    scanf("%f", &new_student.fees);
    
    students[student_count] = new_student;
    student_count++;
    printf("Student added successfully!\n");
}

void searchStudent(int rollno) {
    for (int i = 0; i < student_count; i++) {
        if (students[i].rollno == rollno) {
            printf("Student found:\n");
            printf("Name: %s\n", students[i].name);
            printf("Roll No: %d\n", students[i].rollno);
            printf("Phone No: %s\n", students[i].phoneno);
            printf("Number of Subjects: %d\n", students[i].num_subjects);
            printf("Fees: %.2f\n", students[i].fees);
            return;
        }
    }
    printf("Student with roll number %d not found.\n", rollno);
}

void removeStudent(int rollno) {
    for (int i = 0; i < student_count; i++) {
        if (students[i].rollno == rollno) {
            for (int j = i; j < student_count - 1; j++) {
                students[j] = students[j + 1];
            }
            student_count--;
            printf("Student with roll number %d removed successfully!\n", rollno);
            return;
        }
    }
    printf("Student with roll number %d not found.\n", rollno);
}

int main() {
    int choice, rollno;

    while (1) {
        printf("\nStudent Database Menu:\n");
        printf("1. Add Student\n");
        printf("2. Search Student\n");
        printf("3. Remove Student\n");
        printf("4. Exit\n");
        printf("Enter your choice: ");
        scanf("%d", &choice);

        switch (choice) {
            case 1:
                addStudent();
                break;
            case 2:
                printf("Enter roll number to search: ");
                scanf("%d", &rollno);
                searchStudent(rollno);
                break;
            case 3:
                printf("Enter roll number to remove: ");
                scanf("%d", &rollno);
                removeStudent(rollno);
                break;
            case 4:
                exit(0);
            default:
                printf("Invalid choice! Please try again.\n");
        }
    }

    return 0;
}
#include <stdio.h>

int main()
{
    int a,b;
    scanf("%d %d",&a,&b);
    if (a > b){
        printf("a is greater");
    }
    else if(b> a){
        printf("b is greatest");
        
        
    }
    else{
        printf("Invalid");
    }

    return 0;
}

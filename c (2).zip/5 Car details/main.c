#include <stdio.h>  

struct car  
{  
    int car_count;  
    float car_price;  
    char name[100];  
};  

void printCarDetails(struct car car_info) {  
    printf("Car Name: %s\n", car_info.name);  
    printf("Car Count: %d\n", car_info.car_count);  
    printf("Car Price: %.2f\n\n", car_info.car_price);  
}  

int main()  
{  
    struct car car_list[5];  
    for (int i = 0; i < 5; i++) {  
        printf("Enter details for car %d:\n", i + 1);  

        printf("Enter Car Name: ");  
        scanf(" %[^\n]", car_list[i].name);  

        printf("Enter Car Count: ");  
        scanf("%d", &car_list[i].car_count);  

        printf("Enter Car Price: ");  
        scanf("%f", &car_list[i].car_price);  

        printf("\n");   
    }  
 
    printf("Car Details Entered:\n");  
    for (int i = 0; i < 5; i++) {  
        printCarDetails(car_list[i]);  
    }  

    return 0;  
}
#include <stdio.h>  

struct Student  
{  
    int Student_count;  
    int Student_Phone_No;  
    char name[100];  
};  
void printStudentDetails(struct Student Student_info) {  
    printf("Student Name: %s\n", Student_info.name);  
    printf("Student Count: %d\n", Student_info.Student_count);  
    printf("Student Salary: %d\n\n", Student_info.Student_Phone_No);  
}  
int main()  
{  
    struct Student Student_list[5];  
    for (int i = 0; i < 5; i++) {  
        printf("Enter details for Student %d:\n", i + 1);  

        printf("Enter Student Name: ");  
        scanf(" %[^\n]", Student_list[i].name);  

        printf("Enter Student Count: ");  
        scanf("%d", &Student_list[i].Student_count);  

        printf("Enter Student Phone Number: ");  
        scanf("%d", &Student_list[i].Student_Phone_No);  

        printf("\n");   
    }  
 
    printf("Student Details Entered:\n");  
    for (int i = 0; i < 5; i++) {  
        printStudentDetails(Student_list[i]);  
    }  

    return 0;  
}
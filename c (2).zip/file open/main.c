#include <stdio.h> 
int main()
{
    FILE *fp; 
    fp=fopen("test.txt","w"); 
    char ch=fgetc(fp);
    if(ferror(fp)) {
    printf("File is opened in writing mode! You cannot read data fromg!"); 
    } 
    fclose(fp); 
    return(0);
}
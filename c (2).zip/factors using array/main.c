#include <stdio.h>  

int main() {  
    int n, count = 0;  
    printf("Enter a number: ");  
    scanf("%d", &n);  
    int divisors[n];
    for (int i = 1; i <= n; i++) {  
        if (n % i == 0) {  
            divisors[count] = i; 
            count += 1;            
        }  
    }  
    printf("Divisors: ");  
    for (int i = 0; i < count; i++) {  
        printf("%d ", divisors[i]);  
    }  
    printf("\n");  
    printf("Count of divisors: %d\n", count); 
    if (count > 2) {  
        printf("Not a prime number\n");  
    } else {  
        printf("Prime number\n");  
    }  

    return 0;  
}
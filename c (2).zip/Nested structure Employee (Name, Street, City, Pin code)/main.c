#include <stdio.h>  

struct Address {  
    char street[100];  
    char city[50];  
    int pin_code;  
};  

struct Person {  
    char name[50];  
    struct Address address;  
};  

int main() {  
    struct Person person;  

    printf("Enter name: ");  
    scanf("%s", person.name);  
    printf("Enter street: ");  
    scanf(" %[^\n]", person.address.street);  
    printf("Enter city: ");  
    scanf("%s", person.address.city);  
    printf("Enter pin code: ");  
    scanf("%d", &person.address.pin_code);  

    printf("\nPerson Information:\n");  
    printf("Name: %s\n", person.name);  
    printf("Address: %s, %s, %d\n",   
           person.address.street, person.address.city, person.address.pin_code);  

    return 0;  
}
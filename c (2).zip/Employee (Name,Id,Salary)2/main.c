#include <stdio.h>
struct emp
{
    char Emp_Name[50];
    int Emp_Id;
    float Emp_salary;
};
int main()
{
   struct emp e[3];
   for(int i=0;i<3;i++)
   {
      printf("Enter Name:");
      scanf("%s",e[i].Emp_Name);
      printf("Enter Id:");
      scanf("%d",&e[i].Emp_Id);
      printf("Enter salary:");
      scanf("%f",&e[i].Emp_salary);
   }
   for(int i=0;i<3;i++)
   {
      printf("Name:%s\n",e[i].Emp_Name);
      printf("Id:%d\n",e[i].Emp_Id);
      printf("salary:%f\n",e[i].Emp_salary);
      printf("\n");
   }

    return 0;
}
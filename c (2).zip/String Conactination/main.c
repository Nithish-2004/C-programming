#include <stdio.h>  
#include <string.h>  
int main() {  
    char s[50]="Hello";
    char D[50]="World";
    strcat(D,s);
    
    printf("Concatinated String:%s\n",D);
    //printf("Destination:%s\n",Destination);
    return 0;  
}
#include <stdio.h>
#include <errno.h>
#include <string.h>

int main(){
    FILE *file = fopen("nonexistent.txt","r");
    if(file == NULL){
        perror("File Opening Fail");
    }
    return 0;
}
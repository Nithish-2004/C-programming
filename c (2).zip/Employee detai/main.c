#include <stdio.h>
#include <string.h>
struct data{
    char name[20];
    int empno;
    float sal;
    char cmp[20];
    char loc[20];
};
int main()
{
    struct data d;
        strcpy(d.name,"Vijay");
        strcpy(d.cmp,"TCS");
        strcpy(d.loc,"banglore");
        d.empno=12345;
        d.sal=120000;
    
    return 0;
}

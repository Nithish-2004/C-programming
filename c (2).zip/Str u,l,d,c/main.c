#include <stdio.h>

int main()
{
 char str[50];
 int Up=0,Dig=0,Spl=0,Lp=0;
 scanf("%[^\n]s",str);
 for(int i=0;str[i]!='\0';i++)
 {
  if(str[i]>='a'&&str[i]<='z') 
  {
      Lp++;
  }
  else if(str[i]>='A'&&str[i]<='Z')
  {
      Up++;
  }
   else if(str[i]>='0'&&str[i]<='9')
  {
      Dig++;
  }
  else
  {
      Spl++;
  }
 }
 printf("Up=%d\n Lp=%d\n Dig=%d\n Spl=%d",Up,Lp,Dig,Spl);
}
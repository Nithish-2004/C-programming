#include <stdio.h>

int main()
{
    int a =5;
    do{
    printf("%d",a);
    a +=1;
    }
    while(a>20);

    return 0;
}

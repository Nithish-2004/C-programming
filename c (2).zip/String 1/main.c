#include <stdio.h>

int main()
{
    char str1[20]="Hello";
    char str2[]={'H','e','l','l','o','\0'};
    printf("%s\n%s",str1,str2);

    return 0;
}
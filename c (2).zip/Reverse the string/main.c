#include <stdio.h>  
#include <string.h>  

int main() {  
    char str[100]; 
    int length, i;  

    fgets(str, sizeof(str), stdin);

    length = strlen(str);  
    if (length > 0 && str[length - 1] == '\n') {  
        str[length - 1] = '\0'; 
    }  
    for (i = length - 1; i >= 0; i--) {  
        printf("%c", str[i]);  
    }  
    printf("\n"); 
    return 0;  
}
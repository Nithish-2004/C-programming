#include <stdio.h>

int main()
{
   FILE *fb=fopen("File","a");
  if(fb==NULL){
    printf("File is Not Found");
    return 1;
  }
    //fprintf(fb,"Hello\n");
    //fprintf(fb,"Nithish Kumar S");
    for(int i=0;i<5;i++){
    printf("%c",fgetc(fb));}
    fclose(fb);
    return 0;
}
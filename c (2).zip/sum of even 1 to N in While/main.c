#include <stdio.h>

int main()
{
    int n, i = 1, sum = 0;  
    printf("Enter a Even Number: ");  
    scanf("%d", &n);  
    
    while (i <= n) {  
        if(i % 2 == 0){
        sum += i;  
        }
        i++; 
    }  
    printf("Sum of Even Numbers from 1 to %d is %d\n", n, sum); 
    return 0;
}

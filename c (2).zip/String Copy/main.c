#include <stdio.h>  
#include <string.h>  
int main() {  
    char source[]="Hello";
    char Destination[50];
    strcpy(Destination,source);
    
    printf("Source:%s\n",source);
    printf("Destination:%s\n",Destination);
    return 0;  
}
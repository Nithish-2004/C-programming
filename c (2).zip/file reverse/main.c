#include <stdio.h>  
#include <string.h>  

int main(){  
    FILE *f = fopen("hello.txt","r");  
    char str[100];  
    char ch;  
    if(f==NULL){  
        print("File not Open");  
    }  
    fgets(str, 100, f);  
    for(int i=strlen(str)-1;i>=0;i--){  
        printf("%c",str[i]);  
    }  
    // printf("%s\n",str);  
    fclose(f);  
}
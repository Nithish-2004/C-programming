#include<stdio.h>

struct student{
    char firstname[50];
    char lastname[50];
    int id;
    int sem;
    int arrer;
    long int ph;
};

void Criteria1()
{
    printf("Full scholarship\n top-tier program access\n priority accommodation.\n\n");
}

void Criteria2()
{
    printf("Partial scholarship\n regular program access\n standard accommodation.\n\n");
}

void Criteria3()
{
    printf("Fee waivers\n access to basic programs\n limited accommodation.\n\n");
}

void Criteria4()
{
    printf("Eligibility for financial assistance\n basic program access\n minimal accommodation.\n\n");
}

int main(){
    struct student e[10];
    for(int i=0; i<10; i++){  
        printf("Enter Details of student %d:\n", i+1);
        printf("Enter the First name: ");
        scanf(" %s", e[i].firstname);
        printf("Enter the Last name: ");
        scanf(" %s", e[i].lastname);
        printf("Enter the id: ");
        scanf(" %d", &e[i].id);
        printf("Enter the semester: ");
        scanf(" %d", &e[i].sem);
        printf("Enter the arrear papers: ");
        scanf(" %d", &e[i].arrer);
        printf("Enter the Phone number: ");
        scanf(" %ld", &e[i].ph);
        printf("\n");
    }
    
    for(int i=0; i<10; i++){  
        if(e[i].arrer == 0){
            printf("------------------------------------------------------\n");
            printf("Student Category with no arrear\n");
            printf("------------------------------------------------------\n");
            printf("First name of student: %s\n", e[i].firstname);
            printf("Last name of student: %s\n", e[i].lastname);
            printf("Id of the student: %d\n", e[i].id);
            printf("Total Semester: %d\n", e[i].sem);
            printf("Total arrear still now: %d\n", e[i].arrer);
            printf("Phone number: %ld\n", e[i].ph);
            printf("\n\n");
        }
        else if(e[i].arrer >= 1){
            printf("------------------------------------------------------\n");
            printf("Student Category with arrear\n");
            printf("------------------------------------------------------\n");
            if(e[i].arrer <= (e[i].sem / 2)){
                printf("------------------------------------------------------\n");
                printf("Average student\n");
                printf("------------------------------------------------------\n");
                printf("First name of student: %s\n", e[i].firstname);
                printf("Last name of student: %s\n", e[i].lastname);
                printf("Id of the student: %d\n", e[i].id);
                printf("Total Semester: %d\n", e[i].sem);
                printf("Total arrear still now: %d\n", e[i].arrer);
                printf("Phone number: %ld\n", e[i].ph);
                printf("\n\n");
            }
            else{
                printf("------------------------------------------------------\n");
                printf("Poor student\n");
                printf("------------------------------------------------------\n");
                printf("First name of student: %s\n", e[i].firstname);
                printf("Last name of student: %s\n", e[i].lastname);
                printf("Id of the student: %d\n", e[i].id);
                printf("Total Semester: %d\n", e[i].sem);
                printf("Total arrear still now: %d\n", e[i].arrer);
                printf("Phone number: %ld\n", e[i].ph);
                printf("\n\n");
            }
        }
    }

    int flag=0;
    while(flag==0){
        printf("Welcome\n");
        printf("1.Cutoff == 200\n");
        printf("2.Cutoff >= 180\n");
        printf("3.Cutoff >= 160\n");
        printf("4.Cutoff >= 140\n");
        printf("5. Exit\n");
        printf("Enter Your choice: ");
        int num;
        scanf("%d", &num);
        switch(num)
        {
          case 1:
                 Criteria1();
                 break;
          case  2:
                 Criteria2();
                 break;
          case 3:
                 Criteria3();
                 break;
          case 4:
                 Criteria4();
                 break;
          case 5:
                 flag=1;
                 break;
          default:
                 printf("Check input\n");
        }
    }
    printf("Thank You\n");
    
    return 0;
}

#include <stdio.h>
int add(int a,int b)
{   printf("Addtion\n");
    return a+b;
}
void sub(int a,int b)
{
    printf("Subtraction\n");
    printf("%d- %d-> %d\n",a,b,a-b);
}
int mul()
{
    printf("Mul\n");
    int a,b;
    printf("Enter First Number:");
    scanf("%d",&a);
    printf("Enter Secound Number:");
    scanf("%d",&b);
    return a*b;
}
void  divs()
{
    printf("Divison\n");
    int a,b;
    printf("Enter First Number:");
    scanf("%d",&a);
    printf("Enter Secound Number:");
    scanf("%d",&b);
    printf("%d/ %d-> %d\n",a,b,a/b);
}

int main()
{ 
   int res=add(5,4);
   printf("return value is %d\n",res);
   sub(5,4);
   int res2=mul();
   printf("return value is %d\n",res2);
   divs();
    return 0;
    
}
  


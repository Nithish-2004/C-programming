
#include <stdio.h>

int main()
{
    int a;
    printf("Enter the Number: ");
    
    scanf("%d",&a);
    if((a % 4 == 0 && a % 400 ==0) || (a % 100 != 0)){
        printf(" 'a' is Leap Year");
        
    }else{
        printf(" 'a' is Not a Leap Year");
    }

    return 0;
}
#include <stdio.h>
#include <string.h>

#define MAX_BOOKS 100
#define MAX_NAME_LENGTH 50
#define MAX_AUTHOR_LENGTH 50

typedef struct {
    char name[MAX_NAME_LENGTH];
    char author[MAX_AUTHOR_LENGTH];
    int pages;
    float price;
} Book;

Book library[MAX_BOOKS];
int book_count = 0;

void add_book() {
    if (book_count >= MAX_BOOKS) {
        printf("Library is full! Cannot add more books.\n");
        return;
    }
    
    printf("Enter book name: ");
    scanf(" %[^\n]", library[book_count].name);
    printf("Enter author name: ");
    scanf(" %[^\n]", library[book_count].author);
    printf("Enter pages: ");
    scanf("%d", &library[book_count].pages);
    printf("Enter price: ");
    scanf("%f", &library[book_count].price);
    
    book_count++;
    printf("Book '%s' by %s added successfully.\n", library[book_count - 1].name, library[book_count - 1].author);
}

void display_books() {
    if (book_count == 0) {
        printf("No books in the library.\n");
        return;
    }
    
    for (int i = 0; i < book_count; i++) {
        printf("Name: %s, Author: %s, Pages: %d, Price: %.2f\n", 
               library[i].name, library[i].author, library[i].pages, library[i].price);
    }
}

void list_books_by_author() {
    char author[MAX_AUTHOR_LENGTH];
    printf("Enter author name: ");
    scanf(" %[^\n]", author);
    
    int found = 0;
    for (int i = 0; i < book_count; i++) {
        if (strcasecmp(library[i].author, author) == 0) {
            printf("Name: %s, Pages: %d, Price: %.2f\n", 
                   library[i].name, library[i].pages, library[i].price);
            found = 1;
        }
    }
    
    if (!found) {
        printf("No books found by author '%s'.\n", author);
    }
}

void count_books() {
    printf("Total number of books in the library: %d\n", book_count);
}

int main() {
    int choice;
    
    while (1) {
        printf("\n1. Add book information\n");
        printf("2. Display book information\n");
        printf("3. List all books of given author\n");
        printf("4. List the count of books in the library\n");
        printf("5. Exit\n");
        
        printf("Enter one of the above: ");
        scanf("%d", &choice);
        
        switch (choice) {
            case 1:
                add_book();
                break;
            case 2:
                display_books();
                break;
            case 3:
                list_books_by_author();
                break;
            case 4:
                count_books();
                break;
            case 5:
                printf("Exiting the program.\n");
                return 0;
            default:
                printf("Invalid choice. Please try again.\n");
        }
    }
    
    return 0;
}
#include <stdio.h>  

int main() {
   printf("\"hai\"hello");
    return 0;  
}
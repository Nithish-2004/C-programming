/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>

int main()
{
 char str[50];
 scanf("%[^\n]s",str);
 int length=0;
 for(int i=0;str[i]!='\0';i++)
 {
  length++;   
 }
 char temp=str[0];
 str[0]=str[length-1];
 str[length-1]=temp;

 printf("%s",str);
}
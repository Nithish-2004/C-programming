#include <stdio.h>  

int main() {  
    
    float num1, num2, num3;  

    printf("Enter first number: ");  
    scanf("%f", &num1);  
    printf("Enter second number: ");  
    scanf("%f", &num2);  
    printf("Enter third number: ");  
    scanf("%f", &num3);  
 
    if (num1 == num2 && num2 == num3) {  
        printf("All three numbers are equal.\n");  
    } else {  
        printf("The three numbers are not all equal.\n");  
    }  

    return 0;  
}
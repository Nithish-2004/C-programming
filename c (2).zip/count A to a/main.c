#include <stdio.h>

int main()
{
    char i = 'A';
    int count = 0;
    while(i <= 'z'){
      if ((i >= 'A' && i <= 'Z') || (i >= 'a' && i <= 'z'))
      {
        count++;
        
      }
    i++;
    }
    printf("%d\n",count);
    return 0;
}

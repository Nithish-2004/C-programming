#include <stdio.h>  

int main() {  
    int num;  
    printf("Enter an integer: ");  
    scanf("%d", &num);  
    if (num > 0)  
        printf("The integer is positive.\n");  
    else if (num < 0)  
        printf("The integer is negative.\n");  
    else  
        printf("The integer is zero.\n");  
    
    return 0;  
}
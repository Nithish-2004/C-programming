#include <stdio.h>

int main()
{
    char str1[10];
    //fgets(str1,11,stdin);
scanf("%[^\n]",str1);
    printf("%s",str1);
  
    
    return 0;
}
/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>

int main()
{
    int a[]={4,6,7,8,11,15};
    for(int i=0;i<5;i++)
    {
        int count=0;
        int p=a[i];
        for(int j=1;j<=p;j++)
        {
            if(p%j==0)
            {
                count++;
            }
        }
        if(count==2)
        {
            printf("%d ",p);
        }
        
    }
   
}
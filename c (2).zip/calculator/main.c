#include <stdio.h>
int add(int a,int b)
{
    return a+b;
}
int sub(int a,int b){
    return a-b;
}
int Mu(int a,int b){
    return a*b;
}
int main()
{
    int a=10;
    int b=20;

    printf("%d\n",a+b);
    printf("%d\n",a-b);
    printf("%d\n",a*b);
    
    
    return 0;
}
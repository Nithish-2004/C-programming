/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>
int spy(int num);
int main()
{
    for(int i=1;i<=1000;i++)
    {
        if(spy(i)==1)
        {
            printf("%d ",i);
        }
    }

    return 0;
}
int spy(int num)
{
    int sum=0;
    int p=1;
    while(num!=0)
    {
        sum=sum+num%10;
        p=p*num%10;
        num=num/10;
    }
    if(sum==p)
    {
        return 1;
    }
    else
    {
       return 0;
    }
    
}
#include <stdio.h>
#include <string.h>
int main()
{
    //char str[]="Programming";
    char str1[20];
    fgets(str1,15,stdin);
//scanf("%[^\n]",str1);
  for(int i=0;str1[i]!='\0';i++){
    printf("%c\n",str1[i]);
  }
    //printf("%lu\n",strlen(str1));
  printf("End");
    
    return 0;
}
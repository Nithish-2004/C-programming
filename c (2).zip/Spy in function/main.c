#include <stdio.h>
int p(int num)
{
   int sum=0;
   for(int i=1;i<num;i++)
   {
       if(num%i==0)
       {
           sum=sum+i;
       }
   }if(sum==num)
   {
      return 1;
   }
   else
   {
        return 0;
   }
    
    
    
} 
int main()
{
  for(int i=1;i<=1000;i++)
  {
      if(p(i)==1)
      {
          printf("%d ",i);
      }
  }

    return 0;
}

    

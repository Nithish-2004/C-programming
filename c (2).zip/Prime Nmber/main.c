
#include <stdio.h>
int power(int x,int n)
{
    int p=1;
    while(n!=0)
    {
        p=p*x;
        n--;
    }
    
    
}
void prime(int s ,int e)
{   
    while(s<=e)
    {
        
        int count=0;
        for(int i=1;i<=s;i++)
        {
            if(s%i==0){
            count++;}
        }
        if(count==2)
        {
            printf("%d ",s);
        }
        s++;
    }
}
int main()
{ 
 //printf("%d",power(5,3));
 prime(1,10000);
    return 0;
}
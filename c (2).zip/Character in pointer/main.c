#include <stdio.h>

int main()
{
	char *s= "hello";

	printf("%p ",s);
	return 0;
}

#include <stdio.h>  

int main() {  
    char str[50];  
    printf("Enter a string: ");  
    scanf("%[^\n]", str);   

    printf("Uppercase letters: ");  
    for (int i = 0; str[i] != '\0'; i++) {  

        if (str[i] >= 'A' && str[i] <= 'Z') {  
            printf("%c ", str[i]);  
        }  
    }  

    printf("\nLowercase letters: ");  
    for (int i = 0; str[i] != '\0'; i++) {  
        if (str[i] >= 'a' && str[i] <= 'z') {  
            printf("%c ", str[i]);  
        }  
    }  

    printf("\n");  
    return 0;  
}
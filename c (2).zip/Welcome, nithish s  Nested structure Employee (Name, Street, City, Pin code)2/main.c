#include <stdio.h>
struct Address {
    char street[50];
    char city[50];
    int pinCode;
};

struct Person {
    char name[50];
    int age;
    struct Address address;
};

int main() {
    struct Person p;

    // Input person details
    printf("Enter name: ");
    scanf("%s", p.name);
    printf("Enter age: ");
    scanf("%d", &p.age);
    printf("Enter street: ");
    scanf("%s", p.address.street);
    printf("Enter city: ");
    scanf("%s", p.address.city);
    printf("Enter pin code: ");
    scanf("%d", &p.address.pinCode);

    // Display person details
    printf("\nPerson Details:\n");
    printf("Name: %s\n", p.name);
    printf("Age: %d\n", p.age);
    printf("Address: %s, %s, %d\n", p.address.street, p.address.city, p.address.pinCode);


    return 0;
}
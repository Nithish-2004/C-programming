#include <stdio.h>  
void appa()  
{  
    printf("Appa f\n");  
    amma();
}  
void amma()  
{  
    printf("Amma f\n");  
    son();
}  
void son()  
{  
    printf("son f\n");  
    appa();  
}  

int main()  
{  
    appa();  
    amma();  
    son(); 

    return 0;  
}
#include <stdio.h>  
int main() {  
    FILE * file = fopen("example.txt", "r");  
    if (file == NULL) {  
        perror("Error opening file");  
        return 1;  
    }  
    fgetc(file);  
    clearerr(file);  
    char ch = fgetc(file);  
    if (ch != EOF) {  
        printf("Successfully read character: %c\n", ch);  
    }  
    fclose(file);  
    return 0;  
}
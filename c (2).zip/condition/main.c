#include <stdio.h>  
int main() {  
    float num1, num2;  
    
    printf("Enter first number: ");  
    scanf("%f", &num1);  
    printf("Enter second number: ");  
    scanf("%f", &num2);  
 
    if (num1 == num2) {  
        printf("The two numbers are equal.\n");  
    } else {  
        printf("The two numbers are not equal.\n");  
    }  

    return 0;  
}
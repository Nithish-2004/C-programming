#include <stdio.h>

int main()
{
    long int a;
    printf("Enter the Number: ");
    scanf("%ld",&a);
    switch(a){
        case 1:
        printf("case 1");
        break;
        case 2:
        printf("case 2");
        break;
        case 3:
        printf("case 3");
        break;
        case 4:
        printf("case 4");
        break;
        case 5:
        printf("case 5");
        break;
        case 6:
        printf("case 6");
        break;
        case 7:
        printf("case 7");
        break;
        case 8:
        printf("case 8");
        break;
        case 9:
        printf("case 9");
        break;
        case 10:
        printf("case 10");
        break;
        case 11:
        printf("case 11");
        break;
        case 12:
        printf("case 12");
        break;
        default:
        printf("Invalid");
        
    }
   

    return 0;
}
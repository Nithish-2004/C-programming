#include <stdio.h>  
#include <string.h>  
int main() {  
    char S[50]="Hello";
    char D[50]="World";
    //strcat(D,S);
    if(strcmp(S,D)==0){
        printf("Equal\n");
    }else{
        printf("Not Equal\n");
    }
    //printf("Concatinated String:%s\n",D);
    //printf("Destination:%s\n",Destination);
    return 0;  
}
/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>

int main()
{
 char str[50];
 scanf("%[^\n]s",str);
 for(int i=0;str[i]!='\0';i++)
 {
     if(str[i]>='A'&&str[i]<='Z')
     {
         str[i]=str[i]+32;
     }
     else if(str[i]>='a'&&str[i]<='z')
     {
         str[i]=str[i]-32;
     }
 }
 printf("%s",str);
}
#include <stdio.h>

int main()
{
    int a=5;
    int *ptr=&a;
    int **ptr1=&ptr;
    printf("%p\n",ptr);
    printf("%d\n",**ptr1);
    return 0;
}

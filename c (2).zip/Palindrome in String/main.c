#include <stdio.h>
#include<string.h>
int main()
{
    char s[20];
        char j[20];
        int m=0,c=0;
    scanf("%s", s);
    int a=strlen(s);
    for(int i=a-1;i>=0;i--){
        char b=s[i];
        j[m]=b;
        m++;
    }
    printf("%s",(j));
    for(int i=0;i<a;i++){
        if(s[i]==j[i]){
            c++;
        }
    }
    if(c==a){
        printf("\npalindrome"); 
    }
    else{
        printf("\nnot a palindrome");
    }
    return 0;
}
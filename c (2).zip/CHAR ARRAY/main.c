#include <stdio.h>

int main()
{
    int n;
   scanf("%d",&n);
    char a[n];

    for(char i=0;i<n;i++){
    scanf(" %c",&a[i]);
    
    }
    for(char i=0;i<n;i++){
    printf("%c ",a[i]);
    }
    return 0;
}

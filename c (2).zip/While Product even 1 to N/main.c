#include <stdio.h>  

int main() {  
    int n, i = 1, prod = 1;  
    printf("Enter a Even Number: ");  
    scanf("%d", &n);  

    while (i <= n) {  
        if(i % 2 ==0){
        prod *= i;  
        }
        i++;  
    } 
    printf("Product of Even Numbers from 1 to %d is %d\n", n, prod);  
    return 0;  
}
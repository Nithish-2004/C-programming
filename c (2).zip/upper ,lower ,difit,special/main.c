#include <stdio.h>  
#include <ctype.h>  

void countCharacters(const char *str) {  
    int upper = 0, lower = 0, digits = 0, special = 0;  
    while (*str) {  
        if (isupper(*str)) upper++;  
        else if (islower(*str)) lower++;  
        else if (isdigit(*str)) digits++;  
        else special++;  
        str++;  
    }  
    printf("Upper: %d, Lower: %d, Digits: %d, Special: %d\n", upper, lower, digits, special);  
}  

int main() {  
    const char *inputString = "Hello, World! 123";
    countCharacters(inputString);
    return 0;  
}
#include <stdio.h>  

int main() {  
    char str[50];  
   
    scanf("%[^\n]", str);
    for (int i = 0; i < 4; i++) {  
        printf("%c", str[i]); 
    }  
    return 0;  
}
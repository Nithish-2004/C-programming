#include<stdio.h>
#include<string.h>
int main()
{
	char a[20],b[20],u;
	int j=0;
	scanf("%s",a);
	int n=strlen(a);
	for(int i=0; i<n; i++) {
		if(a[i]=='a'||a[i]=='e'||a[i]=='o'||a[i]=='i'||a[i]=='u') {
			b[i]=a[i]-32;
		}
		else {
			b[i]=a[i];
		}
	}
	printf("%s",b);
	return 0;
}


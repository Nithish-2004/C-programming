#include <stdio.h>
#include <string.h>
int main()
{
    char str[]="Programming";
    //char str1[10];
    //fgets(str1,11,stdin);
//scanf("%[^\n]",str1);
    printf("%lu\n",strlen(str));
  
    
    return 0;
}
#include <stdio.h>
int main()
{
	char str[20];
	int s=0,d;
	scanf("%s",str);
	for(int i=0; str[i]!=0; i++) {
		if(str[i]>='0' && str[i]<='9') {
			d=str[i]-'0';
			s+=d;
		}
	}
	printf("sum:%d",s);
	return 0;
}
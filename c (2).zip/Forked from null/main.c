/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>
int sum(int n)
{
    if(n==1)
    {
        return n;
    }
    return n+sum(n-1);
}


int main()
{
  
 printf("%d",sum(5));

    return 0;
}

    

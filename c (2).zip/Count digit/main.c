#include <stdio.h>
int power(int x,int n)
{
    int p=1;
    while(n!=0)
    {
        p=p*x;
        n--;
    }
    
    
}
void prime(int s ,int e)
{   
    while(s<=e)
    {
        
        int count=0;
        for(int i=1;i>0;i++)
        {
            if(s%i==0
            ){
            count++;}
        }
        if(count==2)
        {
            printf("%d ",s);
        }
        s++;
    }
}
int count_digit(int x)
{
    int count=0;
    while(x!=0)
    {
        count++;
        x=x/10;
    }
    
    return count;
}
int main()
{ 
 //printf("%d",power(5,3));
//prime(1,10000);
 printf("%d",count_digit(2345));
    return 0;
}
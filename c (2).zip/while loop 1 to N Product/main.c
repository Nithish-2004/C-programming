#include <stdio.h>  

int main() {  
    int n, i = 1, prod = 1;  
    printf("Enter a positive integer: ");  
    scanf("%d", &n);  

    while (i <= n) {  
        prod *= i;  
        i++;  
    } 
    printf("Product of natural numbers from 1 to %d is %d\n", n, prod);  
    return 0;  
}
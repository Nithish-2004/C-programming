/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>

int main()
{
 char str[50];
 scanf("%[^\n]s",str);
 int i=0;
 for(i=0;str[i]!='\0';i++)
 {
     if(str[i]>='A'&&str[i]<='Z')
     {
         str[i]=str[i]+32;
     }
 }
 str[i-1]=str[i-1]-32;
 printf("%s",str);
}
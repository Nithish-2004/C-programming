#include <stdio.h>
#include <string.h>
#define MAX_BOOKS 100
struct Book {
    char author[100];
    char name[100];
    float price;
    int pages;
};
void addBook(struct Book books[], int *count) {
    if (*count >= MAX_BOOKS) {
        printf("Library is full! Cannot add more books.\n");
        return;
    }
    printf("Enter Author Name: ");
    getchar(); 
    fgets(books[*count].author, sizeof(books[*count].author), stdin);
    books[*count].author[strcspn(books[*count].author, "\n")] = '\0'; 

    printf("Enter Book Name: ");
    fgets(books[*count].name, sizeof(books[*count].name), stdin);
    books[*count].name[strcspn(books[*count].name, "\n")] = '\0'; 
    printf("Enter Price: ");
    scanf("%f", &books[*count].price);
    printf("Enter Number of Pages: ");
    scanf("%d", &books[*count].pages);
    (*count)++;
    printf("Book added successfully!\n");
}
void searchBook(struct Book books[], int count) {
    if (count == 0) {
        printf("No books in the library to search!\n");
        return;
    }
    char searchName[100];
    printf("Enter the name of the book to search: ");
    getchar();
    fgets(searchName, sizeof(searchName), stdin);
    searchName[strcspn(searchName, "\n")] = '\0'; 

    int found = 0;
    for (int i = 0; i < count; i++) {
        if (strcmp(books[i].name, searchName) == 0) {
            printf("\nBook Found:\n");
            printf("Author: %s\n", books[i].author);
            printf("Name: %s\n", books[i].name);
            printf("Price: %.2f\n", books[i].price);
            printf("Pages: %d\n", books[i].pages);
            found = 1;
            break;
        }
    }

    if (!found) {
        printf("Book not found in the library.\n");
    }
}

void displayBooks(struct Book books[], int count) {
    if (count == 0) {
        printf("No books in the library!\n");
        return;
    }

    printf("\nLibrary Books:\n");
    for (int i = 0; i < count; i++) {
        printf("\nBook %d:\n", i + 1);
        printf("Author: %s\n", books[i].author);
        printf("Name: %s\n", books[i].name);
        printf("Price: %.2f\n", books[i].price);
        printf("Pages: %d\n", books[i].pages);
    }
}

int main() {
    struct Book books[MAX_BOOKS];
    int count = 0;
    int choice;
    int i=1;
    while(i=1){
        printf("\nLibrary Management System\n");
        printf("1. Add Book\n");
        printf("2. Search Book\n");
        printf("3. Display All Books\n");
        printf("4. Exit\n");
        printf("Enter your choice: ");
        scanf("%d", &choice);

        switch (choice) {
            case 1:
                addBook(books, &count);
                break;
            case 2:
                searchBook(books, count);
                break;
            case 3:
                displayBooks(books, count);
                break;
            case 4:
                printf("Exiting...\n");
                return 0;
                break;
            default:
                printf("Invalid choice! Please try again.\n");
        }
    }

    return 0;
}
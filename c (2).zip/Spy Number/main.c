#include <stdio.h>

int main()
{
    int a,sum,b=0,c=1;
    scanf("%d",&a);
    while(a!=0){
        sum=a%10;
        b+=sum;
        c*=sum;
        a/=10;
    }
    if(c==b){
        printf("Spy Number");
        
    }else{
        printf("Not a Spy Number");
    }
    
    return 0;
}
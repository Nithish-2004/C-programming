#include <stdio.h>  

int main()  
{  
    char str[50];  
    printf("Enter a string: ");  
    scanf("%[^\n]", str);
    int len = 0;  
    while (str[len] != '\0') {  
        len++;  
    }  
    for (int i = 0; i < len; i++) {  
        if (str[i] >= 'A' && str[i] <= 'Z') {  
            str[i] = str[i] + 32;
        }  
    }  
    if (len > 0) {  
        if (str[len - 1] >= 'a' && str[len - 1] <= 'z') {  
            str[len - 1] = str[len - 1] - 32;  
        } else if (str[len - 1] >= 'A' && str[len - 1] <= 'Z') {  
            str[len - 1] = str[len - 1];   
        }  
    }  
    printf("Modified string: %s\n", str);  
    return 0;  
}
#include <stdio.h>
void add()
{
    int a,b;
    printf("Enter first number:");
    scanf("%d",&a);
    printf("Enter secound number:");
    scanf("%d",&b);
    printf(" %d + %d = %d\n",a,b,a+b);
    
}
void sub()
{
    int a,b;
    printf("Enter first number:");
    scanf("%d",&a);
    printf("Enter secound number:");
    scanf("%d",&b);
    printf(" %d - %d = %d\n",a,b,a-b);
    
}
void mul()
{
    int a,b;
    printf("Enter first number:");
    scanf("%d",&a);
    printf("Enter secound number:");
    scanf("%d",&b);
    printf(" %d x %d = %d\n",a,b,a*b);
    
}
void divs()
{
    int a,b;
    printf("Enter first number:");
    scanf("%d",&a);
    printf("Enter secound number:");
    scanf("%d",&b);
    printf(" %d / %d = %d\n",a,b,a/b);
    
}
int main() {
    int flag=0;
    while(flag==0){
    printf("Welcome\n");
    printf("1.Addtion two Number\n");
    printf("2.Subtraction two Number\n");
    printf("3.Multiplication two Number\n");
    printf("4.Division two Number");
    printf("5. Exit\n");
    printf("Enter Your choise:");
    int num;
    scanf("%d",&num);
    switch(num)
    {
      case 1:
             add();
             break;
      case  2:
            sub();
            break;
      case 3:
             mul();
             break;
             
      case 4:
             divs();
             break;
      case 5:
             flag=1;
             break;
      default:
            printf("check input\n");
    }
    }
    printf("Thank You\n");
    
    return 0;
}
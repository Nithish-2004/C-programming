#include <stdio.h>  

int main() {  
    int num;  
    printf("Enter an integer: ");  
    scanf("%d", &num);  
    if (num >= 10 && num <= 99)  
        printf("The integer is a special two-digit number.\n");  
    else  
        printf("The integer is not a special two-digit number.\n");  
    
    return 0;  
}
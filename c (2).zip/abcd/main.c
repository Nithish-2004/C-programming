#include <stdio.h>

int main() {
    int i;

    // Loop to print letters A-D four times (as an example)
    for (i = 'A'; i <= 'D'; i++) {
        printf("%c ", i); // Print each letter followed by a space
    }
    
    printf("\n"); // New line after the series of letters

    return 0;
}

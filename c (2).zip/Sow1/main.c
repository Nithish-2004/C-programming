#include<stdio.h>
#include<string.h>
#include<math.h>
#define MAX_STUDENTS 50
struct Student{
     char name[50];
    long int phone_no;
    int roll_no,subjects;
    float fees;
};
struct Student students[MAX_STUDENTS];
int studentcount=0;
void Studentdetail(){
    printf("Student detail\n");
    printf("Enter name:");
    scanf("%s",students[studentcount].name);
    printf("Enter roll number:");
    scanf("%d",&students[studentcount].roll_no);
    printf("Enter number of subjects:");
    scanf("%d",&students[studentcount].subjects);
    printf("Enter phone number:");
    scanf("%ld",&students[studentcount].phone_no);
    printf("Enter fees:");
    scanf("%f",&students[studentcount].fees);
    studentcount++;
}
void find_name(){
    char name[50];
    printf("Enter your name:");
    scanf("%s",name);
     for (int i = 0; i < studentcount; i++) {
         if (strcmp(students[i].name, name) == 0) {
             printf("roll num:%d",students[i].roll_no);
             printf("\nnumber of subjects:%d",students[i].subjects);
             printf("\nphone number:%ld",students[i].phone_no);
             printf("\nfees:%f",students[i].fees);
         }
}}
void find_roll(){
    int roll_no;
    printf("\nenter your roll num:");
    scanf("%d",&roll_no);
    for (int i = 0; i < studentcount; i++) {
        if (students[i].roll_no==roll_no){
            printf("name:%s",students[i].name);
            printf("\nnumber of subjects:%d",students[i].subjects);
             printf("\nphone number:%ld",students[i].phone_no);
             printf("\nfees:%f",students[i].fees);
        }
}}
void deleteStudentByName() {
    char name[50];
    printf("Enter the name of the student to delete: ");
    scanf("%s",name);

    for (int i = 0; i < studentcount; i++) {
        if (strcmp(students[i].name, name) == 0) {
            for (int j = i; j < studentcount - 1; j++) {
                students[j] = students[j + 1];
            }
            studentcount--;
            printf("Student details deleted successfully.\n");
            return;
        }
    }

    printf("Student not found.\n");
}
int main(){
     int choice;

    do {
        printf("\n1. Add Student\n");
        printf("2. Display Student by Roll Number\n");
        printf("3. Display Student by Name\n");
        printf("4. Display Student by Nmae\n");
        printf("5. Exit\n");
        printf("Enter your choice: ");
        scanf("%d", &choice);

        switch (choice) {
            case 1:
                Studentdetail();
                break;
            case 2:
                find_roll();
                break;
            case 3:
               find_name();
                break;
            case 4:
               deleteStudentByName();
                break;
            case 5:
                printf("Exiting program.\n");
                break;
            default:
                printf("Invalid choice. Please try again.\n");
        }
    } while (choice != 5);

    return 0;
}
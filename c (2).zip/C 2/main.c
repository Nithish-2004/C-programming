#include <stdio.h>
int main()
{
	char Name1;
	char Name2;
	char Name3;

	char Dept1;
	char Dept2;
	char Dept3;

	int joinyear1;
	int joinyear2;
	int joinyear3;

	int Endyear1;
	int Endyear2;
	int Endyear3;

	int Subject1;
	int Subject2;
	int Subject3;
	
    int Lab1;
	int Lab2;
	int Lab3;
	
	int Age1;
	int Age2;
	int Age3;
	
	printf("Enter the Name1: ");
	scanf("%c",&Name1);
	printf("Enter the Name2: ");
	scanf(" %c",&Name2);
	printf("Enter the Name3: ");
	scanf(" %c",&Name3);

	printf("Enter the Dept1: ");
	scanf(" %c",&Dept1);
	printf("Enter the Dept2: ");
	scanf(" %c",&Dept2);
	printf("Enter the Dept3: ");
	scanf(" %c",&Dept3);

    printf("Enter the Age1: ");
	scanf("%d",&Age1);
	printf("Enter the Age2: ");
	scanf("%d",&Age2);
	printf("Enter the Age3: ");
	scanf("%d",&Age3);
	 
	printf("Enter the join year1: ");
	scanf("%d",&joinyear1);
	printf("Enter the join year2: ");
	scanf("%d",&joinyear2);
	printf("Enter the join year3: ");
	scanf("%d",&joinyear3);

	printf("Enter the End year1: ");
	scanf("%d",&Endyear1);
	printf("Enter the End year2: ");
	scanf("%d",&Endyear2);
	printf("Enter the End year3: ");
	scanf("%d",&Endyear3);

	printf("Enter the No of Subject1: ");
	scanf("%d",&Subject1);
	printf("Enter the No of Subject2: ");
	scanf("%d",&Subject2);
	printf("Enter the No of Subject: ");
	scanf("%d",&Subject3);

    printf("Enter the No of Lab1: ");
	scanf("%d",&Lab1);
	printf("Enter the No of Lab2: ");
	scanf("%d",&Lab2);
	printf("Enter the No of Lab3: ");
	scanf("%d",&Lab3);

}



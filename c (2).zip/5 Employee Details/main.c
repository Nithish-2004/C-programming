#include <stdio.h>  

struct Employee  
{  
    int Employee_count;  
    float Employee_Salary;  
    char name[100];  
};  
void printEmployeeDetails(struct Employee Employee_info) {  
    printf("Employee Name: %s\n", Employee_info.name);  
    printf("Employee Count: %d\n", Employee_info.Employee_count);  
    printf("Employee Salary: %.2f\n\n", Employee_info.Employee_Salary);  
}  
int main()  
{  
    struct Employee Employee_list[5]; 
    for (int i = 0; i < 5; i++) {  
        printf("Enter details for Employee %d:\n", i + 1);  

        printf("Enter Employee Name: ");  
        scanf(" %[^\n]", Employee_list[i].name);  

        printf("Enter Employee Count: ");  
        scanf("%d", &Employee_list[i].Employee_count);  

        printf("Enter Employee Salary: ");  
        scanf("%f", &Employee_list[i].Employee_Salary);  

        printf("\n");   
    }  
 
    printf("Employee Details Entered:\n");  
    for (int i = 0; i < 5; i++) {  
        printEmployeeDetails(Employee_list[i]);  
    }  

    return 0;  
}
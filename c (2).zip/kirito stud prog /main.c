#include <stdio.h>
#include <string.h>
typedef struct {
    int rollNumber;
    char firstName[100];
    char courseID[100];
} Student;
Student students[100];
int studentCount = 0;
void addStudent();
void findStudentByRollNumber();
void findStudentByFirstName();
void findStudentByCourseID();
void displayTotalStudents();
void deleteStudentByRollNumber();
void updateStudentByRollNumber();
void displayMenu();
void addStudent() {
    if (studentCount>=100) {
        printf("\nMaximum student capacity reached.\n");
        return;
    }
    printf("\nEnter Roll Number: ");
    scanf("%d",&students[studentCount].rollNumber);
    printf("Enter First Name: ");
    scanf("%s",students[studentCount].firstName);
    printf("Enter Course ID: ");
    scanf("%s",students[studentCount].courseID);
    studentCount++;
    printf("\nStudent added successfully!\n");
}
void findStudentByRollNumber() {
    int rollNumber;
    printf("\nEnter Roll Number to search: ");
    scanf("%d", &rollNumber);
    for (int i=0;i<studentCount;i++) {
        if (students[i].rollNumber == rollNumber) {
            printf("\nStudent Found: Roll Number: %d, Name: %s, Course ID: %s\n",
                   students[i].rollNumber, students[i].firstName, students[i].courseID);
            return;
        }
    }
    printf("\nStudent with Roll Number %d not found.\n", rollNumber);
}
void findStudentByFirstName() {
    char firstName[100];
    printf("\nEnter First Name to search: ");
    scanf("%s", firstName);
    for (int i=0;i<studentCount;i++) {
        if (strcmp(students[i].firstName, firstName) == 0) {
            printf("\nStudent Found: Roll Number: %d, Name: %s, Course ID: %s\n",
                   students[i].rollNumber, students[i].firstName, students[i].courseID);
            return;
        }
    }
    printf("\nStudent with First Name %s not found.\n", firstName);
}
void findStudentByCourseID() {
    char courseID[100];
    printf("\nEnter Course ID to search: ");
    scanf("%s", courseID);
    for (int i=0;i<studentCount;i++) {
        if (strcmp(students[i].courseID, courseID) == 0) {
            printf("\nStudent Found: Roll Number: %d, Name: %s, Course ID: %s\n",
                   students[i].rollNumber, students[i].firstName, students[i].courseID);
        }
    }
}
void displayTotalStudents() {
    printf("\nTotal number of students: %d\n", studentCount);
}
void deleteStudentByRollNumber() {
    int rollNumber;
    printf("\nEnter Roll Number to delete: ");
    scanf("%d", &rollNumber);
    for (int i=0;i<studentCount;i++) {
        if (students[i].rollNumber == rollNumber) {
            for (int j=i;j<studentCount-1;j++) {
                students[j] = students[j+1];
            }
            studentCount--;
            printf("\nStudent with Roll Number %d deleted successfully.\n", rollNumber);
            return;
        }
    }
    printf("\nStudent with Roll Number %d not found.\n", rollNumber);
}
void updateStudentByRollNumber() {
    int rollNumber;
    printf("\nEnter Roll Number to update: ");
    scanf("%d",&rollNumber);

    for (int i=0;i<studentCount;i++) {
        if (students[i].rollNumber == rollNumber) {
            printf("\nEnter new First Name: ");
            scanf("%s", students[i].firstName);
            printf("Enter new Course ID: ");
            scanf("%s",students[i].courseID);
            printf("\nStudent details updated successfully!\n");
            return;
        }
    }
    printf("\nStudent with Roll Number %d not found.\n", rollNumber);
}
void displayMenu() {
    printf("\nThe Task that you want to perform\n");
    printf("1. Add the Student Details\n");
    printf("2. Find the Student Details by Roll Number\n");
    printf("3. Find the Student Details by First Name\n");
    printf("4. Find the Student Details by Course ID\n");
    printf("5. Find the Total number of Students\n");
    printf("6. Delete the Student Details by Roll Number\n");
    printf("7. Update the Student Details by Roll Number\n");
    printf("8. Exit\n");
}
int main() {
    int choice;
    do {
        displayMenu();
        printf("\nEnter your choice to find the task: ");
        scanf("%d", &choice);

        switch (choice) {
            case 1:
                addStudent();
                break;
            case 2:
                findStudentByRollNumber();
                break;
            case 3:
                findStudentByFirstName();
                break;
            case 4:
                findStudentByCourseID();
                break;
            case 5:
                displayTotalStudents();
                break;
            case 6:
                deleteStudentByRollNumber();
                break;
            case 7:
                updateStudentByRollNumber();
                break;
            case 8:
                printf("\nExiting program. Goodbye!\n");
                break;
            default:
                printf("\nInvalid choice. Please try again.\n");
        }
    } while (choice != 8);

    return 0;
}
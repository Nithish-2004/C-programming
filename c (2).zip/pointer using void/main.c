#include <stdio.h>  

int main() {  
    
  {  
 int a=5;  
 float b=4.5;  
 char c='s';  
 void* ptr;  
 ptr=&a;  
 printf("a ->%p\n",&a);  
 printf("ptr->%p\n",(int *)ptr);  
 ptr=&b;  
 printf("b-> %p\n",&b);  
 printf("ptr ->%p\n",(float *)ptr);  

    return 0;
  }
}
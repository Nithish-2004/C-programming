#include <stdio.h>
#include <stdlib.h>
int main() {
	int n, s;
	printf("enter array 1 size:");
	scanf("%d", &n);
	printf("enter array 2 size:");
	scanf("%d",&s);
	int a[n],b[s];
	int k=n+s;
	int c[k];
	printf("enter array 1 elements:");
	for (int i = 0; i < n; i++) {
		scanf("%d", &a[i]);
	}
	printf("enter array 2 elements:");
	x`
	for (int j = 0; j < s; j++) {
		scanf("%d", &b[j]);
	}
	for (int i = 0; i < n; i++) {
		c[i] = a[i];
	}
	for (int j = 0; j < s; j++) {
		c[n + j] = b[j];
	}
	printf("union:\n");
	for (int i = 0; i < k; i++) {
		printf("%d ", c[i]);
	}
	return 0;
}
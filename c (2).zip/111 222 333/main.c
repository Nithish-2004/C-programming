#include <stdio.h>

int main() {
    int i, j;

    // Loop to print numbers from 1 to 4
    for (i = 1; i <= 4; i++) {
        // Inner loop to print same number multiple times
        for (j = 1; j <= 4; j++) {
            printf("%d ", i);
        }
        printf("\n"); // New line after each row
    }

    return 0;
}

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

struct Student {
    char name[50];
    int rollno;
    char phoneno[15];
    char department[30];
    float cgpa;
    int num_subjects;
    float fees;
};

struct Student* students = NULL;
int student_capacity = 0; 
int student_count = 0;

void addStudent() {
    if (student_count >= student_capacity) {
        student_capacity = (student_capacity == 0) ? 1 : student_capacity * 2; 
        students = realloc(students, student_capacity * sizeof(struct Student));
        if (students == NULL) {
            printf("Memory allocation failed!\n");
            exit(1);
        }
    }
    
    struct Student new_student;
    printf("Enter student name: ");
    scanf("%s", new_student.name);
    printf("Enter roll number: ");
    scanf("%d", &new_student.rollno);
    printf("Enter phone number: ");
    scanf("%s", new_student.phoneno);
    printf("Enter department: ");
    scanf("%s", new_student.department);
    printf("Enter CGPA: ");
    scanf("%f", &new_student.cgpa);
    printf("Enter number of subjects: ");
    scanf("%d", &new_student.num_subjects);
    printf("Enter fees: ");
    scanf("%f", &new_student.fees);
    
    students[student_count++] = new_student;
    printf("Student added successfully!\n");
}

void searchStudent(char *key, int searchBy) {
    for (int i = 0; i < student_count; i++) {
        int found = 0;
        if (searchBy == 1 && students[i].rollno == atoi(key)) {
            found = 1;
        } else if (searchBy == 2 && strcmp(students[i].name, key) == 0) {
            found = 1;
        } else if (searchBy == 3 && strcmp(students[i].phoneno, key) == 0) {
            found = 1;
        }
        
        if (found) {
            printf("Student found:\n");
            printf("Name: %s, Roll No: %d, Phone No: %s, Department: %s, CGPA: %.2f, Subjects: %d, Fees: %.2f\n",
                   students[i].name, students[i].rollno, students[i].phoneno, students[i].department,
                   students[i].cgpa, students[i].num_subjects, students[i].fees);
            return;
        }
    }
    printf("Student not found.\n");
}

void removeStudent(char *key, int removeBy) {
    for (int i = 0; i < student_count; i++) {
        int found = 0;
        if (removeBy == 1 && students[i].rollno == atoi(key)) {
            found = 1;
        } else if (removeBy == 2 && strcmp(students[i].name, key) == 0) {
            found = 1;
        } else if (removeBy == 3 && strcmp(students[i].phoneno, key) == 0) {
            found = 1;
        }
        
        if (found) {
            for (int j = i; j < student_count - 1; j++) {
                students[j] = students[j + 1];
            }
            student_count--;
            printf("Student removed successfully!\n");
            return;
        }
    }
    printf("Student not found.\n");
}

void freeMemory() {
    free(students);
}

int main() {
    int choice;
    char key[50];

    while (1) {
        printf("\nStudent Database Menu:\n");
        printf("1. Add Student\n");
        printf("2. Search Student by Roll No\n");
        printf("3. Search Student by Name\n");
        printf("4. Search Student by Phone No\n");
        printf("5. Remove Student by Roll No\n");
        printf("6. Remove Student by Name\n");
        printf("7. Remove Student by Phone No\n");
        printf("8. Exit\n");
        printf("Enter your choice: ");
        scanf("%d", &choice);

        switch (choice) {
            case 1:
                addStudent();
                break;
            case 2:
                printf("Enter roll number to search: ");
                scanf("%s", key);
                searchStudent(key, 1);
                break;
            case 3:
                printf("Enter name to search: ");
                scanf("%s", key);
                searchStudent(key, 2);
                break;
            case 4:
                printf("Enter phone number to search: ");
                scanf("%s", key);
                searchStudent(key, 3);
                break;
            case 5:
                printf("Enter roll number to remove: ");
                scanf("%s", key);
                removeStudent(key, 1);
                break;
            case 6:
                printf("Enter name to remove: ");
                scanf("%s", key);
                removeStudent(key, 2);
                break;
            case 7:
                printf("Enter phone number to remove: ");
                scanf("%s", key);
                removeStudent(key, 3);
                break;
            case 8:
                freeMemory();
                exit(0);
            default:
                printf("Invalid choice! Please try again.\n");
        }
    }

    return 0;
}
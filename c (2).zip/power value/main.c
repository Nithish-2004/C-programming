#include <stdio.h>
{  

int power(int x,int n)  
    int p=1;  
    while(n!=0)  
    {  
        p=p*x;  
        n--;  
    }  
}
int main()  
{  
    printf("%d", power(5,10));  
    return 0;  
}
  
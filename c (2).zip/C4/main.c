#include <stdio.h>  

int main()  
{  
    int diameter;  
    float radius;
    scanf("%d", &diameter);
    radius =  diameter/ 2.0;
    printf("Radius: %f\n", radius);
    return 0;  
}
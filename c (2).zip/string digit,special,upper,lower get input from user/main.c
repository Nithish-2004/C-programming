#include <stdio.h>
int main()
{
	char str[20];
	int u=0,l=0,d=0,s=0;
	scanf("%s",str);
	for(int i=0; str[i]!=0; i++) {
		if(str[i]>='A' && str[i]<='Z'){
		   u+=1;
		}
		else if(str[i]>='a' && str[i]<='z'){
		   l+=1;
		}
		else if(str[i]>='0' && str[i]<='9'){
		   d+=1;
		}
		else{
		   s+=1;
		}
	}
	printf("upper case:%d\n",u);
	printf("lower case:%d\n",l);
	printf("digit:%d\n",d);
	printf("special character:%d",s);
	return 0;
}
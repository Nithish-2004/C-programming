#include <stdio.h>

int main()
{
    char i = 'A';
    while(i <= 'Z'){
    printf("%c\n",i);
    i++;
    }
    
    return 0;
}

#include <stdio.h>  
void add(int a, int b) {  
    printf("%d\n", a + b);  
}  
void sub(int a, int b) {  
    printf("%d\n", a - b);  
}  
void Mu(int a, int b) {  
    printf("%d\n", a * b);  
} 
void Div(int a, int b) {
    printf("%d\n",a % b);
}
int main() {  
    int a = 10;  
    int b = 05;  
    add(a, b);  
    sub(a, b);  
    Mu(a, b);  
    Div(a, b);
    return 0;  
}